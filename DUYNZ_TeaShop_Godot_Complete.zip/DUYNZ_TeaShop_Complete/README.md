# DUYNZ Tea Shop Tycoon — Godot 4

Game quản lý tiệm trà sữa 2D màn hình ngang, không cần viết HTML thủ công.

## Chạy trên máy
1. Cài Godot 4.x.
2. Import thư mục project.
3. Mở `project.godot`.
4. Nhấn F6/F5 để chạy.

## Đưa project lên GitHub
- Tạo repository mới.
- Upload toàn bộ nội dung của thư mục này.
- Không chỉ upload `main.gd`.

## Build Web để chạy bằng GitHub Pages
Trong Godot:
1. Project → Export.
2. Add preset → Web.
3. Chọn thư mục `build/`.
4. Export Project.
5. Upload toàn bộ thư mục web build lên GitHub Pages.

Nếu muốn GitHub Actions tự build, xem `.github/workflows/build-web.yml`.

## Build Android
1. Cài Android SDK/JDK theo Godot Export → Android.
2. Project → Export → Android.
3. Chọn APK/AAB.
4. Dùng keystore riêng khi phát hành thật.

## Lưu game
Game tự lưu vào `user://duynz_tea_shop_v2.json`.

## Điều khiển
- Chuột hoặc cảm ứng.
- Thiết kế chính: 1280×720, màn hình ngang.
- Mở game lần đầu: nhập tên thương hiệu và tên chi nhánh.

## Lưu ý bản quyền
Các hình/nhân vật trong project được vẽ bằng Godot code, không lấy asset của game trong ảnh tham khảo. Âm thanh nền là audio procedural đơn giản được tạo cho project.
