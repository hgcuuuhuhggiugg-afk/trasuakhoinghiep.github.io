extends Control

# DUYNZ Tea Shop Tycoon
# Single-scene, asset-light Godot 4 game. Designed for landscape touch / mouse.

const SAVE_KEY := "duynz_tea_shop_v2"
const START_MONEY := 100000
const DAY_LENGTH := 150.0
const MAX_PATIENCE := 100.0

var brand_name := "DUYNZ"
var branch_name := "Tiệm Trà Sữa Nhỏ"
var money := START_MONEY
var rating := 5.0
var level := 1
var xp := 0
var day := 1
var cleanliness := 52
var served := 0
var revenue_today := 0
var cost_today := 0
var tax_today := 0
var debt := 0
var credit := 650
var bank_unlocked := true
var current_tab := "counter"
var weather := "Nắng nhẹ"
var day_time := 9.0
var day_clock := 0.0
var tutorial_done := false
var music_on := true
var sound_on := true
var customer_id := 0
var customer := {}
var patience := MAX_PATIENCE
var selected_size := "L"
var selected_base := "Trà sữa"
var selected_topping := "Trân châu đen"
var selected_sugar := 50
var selected_ice := "Không đá"
var selected_foam := "Foam matcha"
var recipe_step := 0
var recipe_started := false
var brew_quality := 100
var delivery_orders: Array = []
var reviews: Array = []
var notifications: Array = []
var inventory := {
    "Trà sữa": 8, "Matcha": 5, "Hồng trà": 7, "Lục trà": 6, "Olong": 5, "Trà thái": 5,
    "Trân châu đen": 5, "Trân châu vàng": 5, "Thạch dừa": 5, "Pudding": 4,
    "Foam cheese": 5, "Foam matcha": 5, "Foam muối": 5, "Foam ube": 5,
    "Đá viên": 8, "Ly M": 12, "Ly L": 10, "Đường": 12
}
var prices := {"M": 22000, "L": 28000}
var upgrades := {"machine": 1, "decor": 1, "speed": 1, "storage": 1, "marketing": 1}
var staff := {"barista": 0, "cashier": 0, "cleaner": 0, "shipper": 0}

var font: Font
var bg := Color("#F7EBDD")
var cream := Color("#FFF7EA")
var brown := Color("#5C4033")
var dark := Color("#3B2A25")
var pink := Color("#E98A98")
var pink2 := Color("#F7C4C9")
var green := Color("#7BCB98")
var mint := Color("#BCE4CF")
var gold := Color("#F1C76B")
var red := Color("#E66C6C")
var panel := Color("#FFFDF7")

var ui_layer: Control
var start_panel: Panel
var brand_edit: LineEdit
var branch_edit: LineEdit
var help_panel: Panel
var toast_label: Label
var clock_label: Label
var money_label: Label
var rating_label: Label
var level_label: Label
var order_label: Label
var patience_bar: ProgressBar
var recipe_status: Label
var bottom_info: Label
var customer_name_label: Label
var tab_buttons := {}
var ingredient_buttons: Array[Button] = []
var size_buttons: Array[Button] = []
var base_buttons: Array[Button] = []
var topping_buttons: Array[Button] = []
var foam_buttons: Array[Button] = []
var ice_buttons: Array[Button] = []
var sugar_slider: HSlider
var brew_button: Button
var serve_button: Button
var clean_button: Button
var end_day_button: Button
var audio_player: AudioStreamPlayer
var click_player: AudioStreamPlayer
var success_player: AudioStreamPlayer

func _ready() -> void:
    font = ThemeDB.fallback_font
    set_process(true)
    _load_game()
    _build_audio()
    _build_ui()
    queue_redraw()
    if not tutorial_done:
        _show_start()
    else:
        _spawn_customer()

func _build_audio() -> void:
    audio_player = AudioStreamPlayer.new()
    click_player = AudioStreamPlayer.new()
    success_player = AudioStreamPlayer.new()
    add_child(audio_player); add_child(click_player); add_child(success_player)
    var music = load("res://assets/audio/chill_loop.wav")
    var click = load("res://assets/audio/click.wav")
    var success = load("res://assets/audio/success.wav")
    audio_player.stream = music
    click_player.stream = click
    success_player.stream = success
    audio_player.volume_db = -15
    if music_on: audio_player.play()

func _process(delta: float) -> void:
    day_clock += delta
    day_time += delta / 60.0
    if day_time >= 22.0:
        day_time = 9.0
    if not customer.is_empty() and not start_panel.visible:
        patience = max(0.0, patience - delta * (0.34 + float(max(0, 4-upgrades.speed))*0.02))
        patience_bar.value = patience
        if patience <= 0:
            _customer_left_angry()
    if day_clock > 18.0 and delivery_orders.size() < 2 and randi() % 100 < 2:
        _create_delivery()
    if day_clock > DAY_LENGTH:
        _end_day(false)
    _update_clock()
    queue_redraw()

func _draw() -> void:
    draw_rect(Rect2(0,0,size.x,size.y), bg)
    _draw_backdrop()
    _draw_shop_scene()
    _draw_customer()
    _draw_counter_area()
    _draw_notifications()

func _draw_backdrop() -> void:
    # striped awning
    draw_rect(Rect2(0,0,1280,104), Color("#F9E8D3"))
    for i in range(10):
        var c = Color("#EFA4A9") if i % 2 == 0 else Color("#FFF3E5")
        draw_rect(Rect2(i*128,0,128,82), c)
    draw_line(Vector2(0,82), Vector2(1280,82), Color("#D49C86"), 3)
    # wall and window
    draw_rect(Rect2(0,104,1280,350), Color("#F4DCC1"))
    draw_rect(Rect2(820,125,390,250), Color("#D8EEF0"))
    for x in [850, 960, 1070]: draw_line(Vector2(x,125), Vector2(x,375), Color("#B7C9C8"), 4)
    draw_line(Vector2(820,250), Vector2(1210,250), Color("#B7C9C8"), 4)
    # shelves
    draw_rect(Rect2(30,110,670,20), Color("#C48B6C"))
    draw_rect(Rect2(30,280,670,20), Color("#C48B6C"))
    # jars / tea dispensers
    var labels = ["TRÀ\nSỮA","MATCHA","HỒNG\nTRÀ","LỤC\nTRÀ","OLONG","TRÀ\nTHÁI"]
    var cols = [Color("#D8B69B"),Color("#AFCB73"),Color("#C76A62"),Color("#78AA72"),Color("#A7834F"),Color("#E19B50")]
    for i in range(6):
        var x = 45 + i*104
        draw_rect(Rect2(x,155,82,105), Color("#E9E0D5"), true)
        draw_rect(Rect2(x+8,178,66,65), cols[i], true)
        draw_circle(Vector2(x+41,163), 13, Color("#C0A88C"))
        draw_string(font, Vector2(x+10,218), labels[i], HORIZONTAL_ALIGNMENT_CENTER, 62, 12, dark)
    # machine
    draw_rect(Rect2(590,150,110,120), Color("#B7B1AA"), true)
    draw_rect(Rect2(602,162,86,45), Color("#D7ECE6"), true)
    draw_circle(Vector2(645,184), 16, Color("#6B9F83"))
    draw_rect(Rect2(620,218,50,30), Color("#7C7772"), true)
    # floor
    draw_rect(Rect2(0,454,1280,266), Color("#D6B08D"))
    for y in range(480,720,48): draw_line(Vector2(0,y),Vector2(1280,y),Color("#C89D7B"),2)
    for x in range(-40,1320,80): draw_line(Vector2(x,454),Vector2(x+30,720),Color("#C89D7B"),1)

func _draw_shop_scene() -> void:
    # sign
    draw_rect(Rect2(425,22,430,58), Color("#FFF7EA"), true)
    draw_rect(Rect2(425,22,430,58), Color("#C58C73"), false, 3)
    draw_string(font, Vector2(445,59), brand_name.to_upper(), HORIZONTAL_ALIGNMENT_CENTER, 390, 28, brown)
    draw_string(font, Vector2(460,76), branch_name, HORIZONTAL_ALIGNMENT_CENTER, 360, 12, Color("#8D6657"))
    # clock / status
    draw_circle(Vector2(1180,52), 25, Color("#FFF7EA"))
    draw_string(font, Vector2(1160,57), "☼", HORIZONTAL_ALIGNMENT_CENTER, 40, 20, gold)
    # work table
    draw_rect(Rect2(735,390,520,55), Color("#B9795F"), true)
    draw_rect(Rect2(735,445,520,35), Color("#8D5948"), true)
    # cups stack
    for i in range(5):
        draw_rect(Rect2(760+i*4,335-i*4,70-i*2,70), Color("#F7F0E8"), true)
        draw_line(Vector2(770+i*4,350-i*4), Vector2(820+i*2,350-i*4), Color("#D8C9B8"),2)
    # toppings tray
    draw_rect(Rect2(840,320,380,72), Color("#D7D1C9"), true)
    var topcols=[Color("#4A2D27"),Color("#E6B45B"),Color("#B36C49"),Color("#F17E95"),Color("#9DD87C")]
    for i in range(5):
        draw_rect(Rect2(850+i*72,331,60,48), Color("#F3EEE6"), true)
        draw_circle(Vector2(880+i*72,355), 18, topcols[i])
    # recipe card
    draw_rect(Rect2(40,385,300,80), Color("#FFF7EA"), true)
    draw_string(font, Vector2(58,413), "SỔ PHA CHẾ", HORIZONTAL_ALIGNMENT_LEFT,-1,16,brown)
    draw_string(font, Vector2(58,438), "Chạm từng bước để pha đúng đơn", HORIZONTAL_ALIGNMENT_LEFT,-1,12,Color("#8D6657"))

func _draw_customer() -> void:
    if customer.is_empty(): return
    var cx := 245.0
    var cy := 238.0
    # full body chibi character
    draw_circle(Vector2(cx,cy-68), 42, Color("#F6C9B4"))
    draw_circle(Vector2(cx-23,cy-93), 20, Color("#4B312E"))
    draw_circle(Vector2(cx+23,cy-93), 20, Color("#4B312E"))
    draw_arc(Vector2(cx,cy-68),42,3.2,6.2,30,Color("#4B312E"),12)
    draw_circle(Vector2(cx-14,cy-68),4,Color("#3A2A2A")); draw_circle(Vector2(cx+14,cy-68),4,Color("#3A2A2A"))
    draw_line(Vector2(cx-5,cy-52),Vector2(cx+5,cy-52),Color("#B7656C"),2)
    draw_rect(Rect2(cx-43,cy-25,86,78), Color("#E8A0A9"), true)
    draw_colored_polygon(PackedVector2Array([Vector2(cx-43,cy-25),Vector2(cx,cy+5),Vector2(cx+43,cy-25)]),Color("#FFF3E6"))
    draw_line(Vector2(cx-22,cy+53),Vector2(cx-27,cy+102),brown,12)
    draw_line(Vector2(cx+22,cy+53),Vector2(cx+27,cy+102),brown,12)
    draw_line(Vector2(cx-43,cy+0),Vector2(cx-75,cy+33),Color("#F6C9B4"),12)
    draw_line(Vector2(cx+43,cy+0),Vector2(cx+75,cy+25),Color("#F6C9B4"),12)
    # speech bubble
    draw_rect(Rect2(330,138,430,150), Color("#FFFDF8"), true)
    draw_colored_polygon(PackedVector2Array([Vector2(330,230),Vector2(292,248),Vector2(330,258)]),Color("#FFFDF8"))
    var cname = str(customer.get("name","Khách"))
    draw_string(font, Vector2(355,169), cname, HORIZONTAL_ALIGNMENT_LEFT,-1,18,brown)
    draw_string(font, Vector2(355,195), "Đơn: " + str(customer.get("drink","Trà sữa")), HORIZONTAL_ALIGNMENT_LEFT,-1,15,dark)
    draw_string(font, Vector2(355,219), str(customer.get("size","L"))+" • "+str(customer.get("sugar",50))+"% đường • "+str(customer.get("ice","Không đá")), HORIZONTAL_ALIGNMENT_LEFT,-1,13,Color("#72584D"))
    draw_string(font, Vector2(355,243), "Topping: "+str(customer.get("topping","Trân châu đen")), HORIZONTAL_ALIGNMENT_LEFT,-1,13,Color("#72584D"))
    draw_string(font, Vector2(355,267), "Foam: "+str(customer.get("foam","Không foam")), HORIZONTAL_ALIGNMENT_LEFT,-1,13,Color("#72584D"))

func _draw_counter_area() -> void:
    draw_string(font,Vector2(38,500),"PHA LY",HORIZONTAL_ALIGNMENT_LEFT,-1,20,brown)
    draw_rect(Rect2(35,515,300,145),Color("#FFF8EF"),true)
    draw_rect(Rect2(55,545,95,95),Color("#E7E0D9"),true)
    draw_rect(Rect2(58,565,89,72),Color("#D6A17D"),true)
    draw_string(font,Vector2(175,550),"BƯỚC "+str(recipe_step)+" / 6",HORIZONTAL_ALIGNMENT_LEFT,-1,17,brown)
    var steps=["Chọn ly","Chọn trà","Topping","Đường","Đá","Foam"]
    for i in range(6):
        var col=green if i < recipe_step else Color("#D8C8B9")
        draw_circle(Vector2(185+i*44,585),14,col)
        draw_string(font,Vector2(178+i*44,590),str(i+1),HORIZONTAL_ALIGNMENT_CENTER,14,10,Color.WHITE)
        draw_string(font,Vector2(160+i*44,620),steps[i],HORIZONTAL_ALIGNMENT_CENTER,45,9,Color("#755A4B"))

func _draw_notifications() -> void:
    var y=112
    for n in notifications:
        draw_rect(Rect2(950,y,300,34),Color(0.25,0.17,0.14,0.88),true)
        draw_string(font,Vector2(963,y+23),n,HORIZONTAL_ALIGNMENT_LEFT,270,12,Color.WHITE)
        y+=39

func _build_ui() -> void:
    ui_layer=Control.new(); ui_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); add_child(ui_layer)
    _build_topbar()
    _build_side_tabs()
    _build_work_controls()
    _build_start_panel()
    _build_help()

func _label(text:String, pos:Vector2, font_size:int=14) -> Label:
    var l=Label.new(); l.text=text; l.position=pos; l.add_theme_font_override("font",font); l.add_theme_font_size_override("font_size",font_size); l.add_theme_color_override("font_color",dark); ui_layer.add_child(l); return l

func _build_topbar() -> void:
    var bar=ColorRect.new(); bar.color=Color("#4B332C"); bar.position=Vector2(0,0); bar.size=Vector2(1280,104); ui_layer.add_child(bar)
    clock_label=_label("09:00",Vector2(25,18),20); clock_label.add_theme_color_override("font_color",Color.WHITE)
    money_label=_label("💰 100.000đ",Vector2(170,18),20); money_label.add_theme_color_override("font_color",Color("#FFE39A"))
    rating_label=_label("⭐ 5.0",Vector2(360,18),20); rating_label.add_theme_color_override("font_color",Color("#FFF1B2"))
    level_label=_label("Lv 1 • 0/100 XP",Vector2(485,18),20); level_label.add_theme_color_override("font_color",Color.WHITE)
    customer_name_label=_label("",Vector2(700,18),18); customer_name_label.add_theme_color_override("font_color",Color("#FFDDE1"))
    patience_bar=ProgressBar.new(); patience_bar.position=Vector2(700,55); patience_bar.size=Vector2(250,22); patience_bar.max_value=100; patience_bar.value=100; patience_bar.show_percentage=false; ui_layer.add_child(patience_bar)
    var help= _button("❓",Vector2(1090,15),Vector2(55,55),_toggle_help); help.tooltip_text="Hướng dẫn"
    var settings=_button("⚙",Vector2(1150,15),Vector2(55,55),_toggle_help)

func _build_side_tabs() -> void:
    var names=["counter:🧋 Quầy","inventory:📦 Kho","upgrade:🔧 Nâng cấp","reviews:💬 Đánh giá","bank:🏦 Ngân hàng"]
    for i in range(names.size()):
        var p=names[i].split(":")
        var b=_button(p[1],Vector2(10,115+i*52),Vector2(175,44),func(): _switch_tab(p[0]))
        tab_buttons[p[0]]=b
    end_day_button=_button("🌙 Kết thúc ngày",Vector2(10,610),Vector2(175,50),func(): _end_day(true))
    clean_button=_button("🧹 Dọn quán",Vector2(10,550),Vector2(175,45),_clean_shop)

func _build_work_controls() -> void:
    # Controls at bottom right
    _label("SIZE",Vector2(360,500),13)
    for i in range(2):
        var s=["M","L"][i]; var b=_button(s,Vector2(360+i*62,520),Vector2(52,42),func(): _choose_size(s)); size_buttons.append(b)
    _label("TRÀ NỀN",Vector2(490,500),13)
    var bases=["Trà sữa","Matcha","Hồng trà","Lục trà","Olong","Trà thái"]
    for i in range(bases.size()):
        var b=_button(bases[i],Vector2(490+(i%3)*100,520+int(i/3)*46),Vector2(92,40),func(): _choose_base(bases[i])); base_buttons.append(b)
    _label("TOPPING",Vector2(800,500),13)
    var tops=["Trân châu đen","Trân châu vàng","Thạch dừa","Pudding"]
    for i in range(tops.size()):
        var b=_button(tops[i],Vector2(800+(i%2)*112,520+int(i/2)*46),Vector2(106,40),func(): _choose_topping(tops[i])); topping_buttons.append(b)
    _label("FOAM / ĐÁ",Vector2(1035,500),13)
    var foams=["Không foam","Foam cheese","Foam matcha","Foam muối","Foam ube"]
    for i in range(foams.size()):
        var b=_button(foams[i],Vector2(1035,520+i*29),Vector2(110,25),func(): _choose_foam(foams[i])); foam_buttons.append(b)
    _label("ĐÁ",Vector2(360,625),12)
    var ices=["Không đá","Ít đá","Bình thường"]
    for i in range(ices.size()):
        var b=_button(ices[i],Vector2(400+i*82,615),Vector2(76,34),func(): _choose_ice(ices[i])); ice_buttons.append(b)
    _label("Đường",Vector2(650,625),12)
    sugar_slider=HSlider.new(); sugar_slider.position=Vector2(705,615); sugar_slider.size=Vector2(180,34); sugar_slider.min_value=0; sugar_slider.max_value=100; sugar_slider.step=10; sugar_slider.value=50; sugar_slider.value_changed.connect(_sugar_changed); ui_layer.add_child(sugar_slider)
    recipe_status=_label("Chưa bắt đầu pha",Vector2(900,610),14)
    brew_button=_button("▶ BẮT ĐẦU PHA",Vector2(900,642),Vector2(155,45),_start_brew)
    serve_button=_button("🧋 GIAO KHÁCH",Vector2(1065,642),Vector2(160,45),_serve_customer)
    bottom_info=_label("Chọn đúng đơn rồi pha từng bước.",Vector2(360,680),14)

func _button(text:String,pos:Vector2,sz:Vector2,cb:Callable) -> Button:
    var b=Button.new(); b.text=text; b.position=pos; b.size=sz; b.add_theme_font_override("font",font); b.add_theme_font_size_override("font_size",13); b.add_theme_color_override("font_color",brown); b.add_theme_color_override("font_hover_color",dark); b.pressed.connect(cb); ui_layer.add_child(b); return b

func _build_start_panel() -> void:
    start_panel=Panel.new(); start_panel.position=Vector2(310,95); start_panel.size=Vector2(660,540); ui_layer.add_child(start_panel)
    var title=Label.new(); title.text="DUYNZ TEA SHOP"; title.position=Vector2(195,30); title.add_theme_font_override("font",font); title.add_theme_font_size_override("font_size",32); title.add_theme_color_override("font_color",brown); start_panel.add_child(title)
    var sub=Label.new(); sub.text="Bắt đầu từ một tiệm nhỏ và xây thành chuỗi cửa hàng."; sub.position=Vector2(110,78); sub.add_theme_font_override("font",font); sub.add_theme_font_size_override("font_size",16); start_panel.add_child(sub)
    var l1=Label.new(); l1.text="Tên thương hiệu"; l1.position=Vector2(100,130); l1.add_theme_font_override("font",font); l1.add_theme_font_size_override("font_size",14); start_panel.add_child(l1)
    brand_edit=LineEdit.new(); brand_edit.position=Vector2(100,155); brand_edit.size=Vector2(460,48); brand_edit.text=brand_name; start_panel.add_child(brand_edit)
    var l2=Label.new(); l2.text="Tên chi nhánh đầu tiên"; l2.position=Vector2(100,220); l2.add_theme_font_override("font",font); l2.add_theme_font_size_override("font_size",14); start_panel.add_child(l2)
    branch_edit=LineEdit.new(); branch_edit.position=Vector2(100,245); branch_edit.size=Vector2(460,48); branch_edit.text=branch_name; start_panel.add_child(branch_edit)
    var welcome=Label.new(); welcome.text="Vốn khởi nghiệp: 100.000đ\nHãy dọn quán, học cách pha và phục vụ khách."; welcome.position=Vector2(100,315); welcome.add_theme_font_override("font",font); welcome.add_theme_font_size_override("font_size",15); start_panel.add_child(welcome)
    var start=Button.new(); start.text="✨ MỞ CỬA QUÁN"; start.position=Vector2(205,390); start.size=Vector2(250,58); start.add_theme_font_override("font",font); start.pressed.connect(_start_game); start_panel.add_child(start)

func _build_help() -> void:
    help_panel=Panel.new(); help_panel.position=Vector2(260,100); help_panel.size=Vector2(760,520); help_panel.visible=false; ui_layer.add_child(help_panel)
    var t=Label.new(); t.text="HƯỚNG DẪN DUYNZ"; t.position=Vector2(240,30); t.add_theme_font_override("font",font); t.add_theme_font_size_override("font_size",28); help_panel.add_child(t)
    var body="1. Khách gọi món và thanh kiên nhẫn sẽ giảm.\n2. Chọn đúng size, trà, topping, đường, đá và foam.\n3. Nhấn BẮT ĐẦU PHA để đi qua 6 bước.\n4. Giao đúng ly để nhận tiền, XP và đánh giá.\n5. Kho giảm sau mỗi lần bán; mua thêm ở tab Kho.\n6. Nâng cấp máy, tốc độ, trang trí và kho.\n7. Ngân hàng cho vay, nhưng nợ phải trả cuối ngày.\n8. Dọn quán giúp rating ổn định hơn.\n9. Sau vài ngày bạn có thể mở chi nhánh mới.\n10. Game tự lưu vào máy bằng localStorage."
    var bl=Label.new(); bl.text=body; bl.position=Vector2(70,85); bl.add_theme_font_override("font",font); bl.add_theme_font_size_override("font_size",16); help_panel.add_child(bl)
    var close=Button.new(); close.text="Đóng"; close.position=Vector2(300,420); close.size=Vector2(150,45); close.add_theme_font_override("font",font); close.pressed.connect(_toggle_help); help_panel.add_child(close)

func _show_start() -> void:
    start_panel.visible=true
    _set_game_buttons(false)

func _start_game() -> void:
    brand_name=brand_edit.text.strip_edges(); if brand_name=="": brand_name="DUYNZ"
    branch_name=branch_edit.text.strip_edges(); if branch_name=="": branch_name="Tiệm Trà Sữa Nhỏ"
    tutorial_done=true; start_panel.visible=false; _set_game_buttons(true); _save_game(); _spawn_customer(); _toast("Quán đã mở! Dọn quán rồi nhận đơn đầu tiên.")

func _set_game_buttons(enabled:bool) -> void:
    for b in ingredient_buttons+size_buttons+base_buttons+topping_buttons+foam_buttons+ice_buttons:
        b.disabled=not enabled
    if brew_button: brew_button.disabled=not enabled
    if serve_button: serve_button.disabled=not enabled
    if clean_button: clean_button.disabled=not enabled
    if end_day_button: end_day_button.disabled=not enabled

func _toggle_help() -> void:
    help_panel.visible=not help_panel.visible
    if help_panel.visible: _set_game_buttons(false)
    else: _set_game_buttons(true)

func _switch_tab(tab:String) -> void:
    current_tab=tab
    if tab=="counter": _toast("Quầy pha chế sẵn sàng.")
    elif tab=="inventory": _open_inventory()
    elif tab=="upgrade": _open_upgrade()
    elif tab=="reviews": _open_reviews()
    elif tab=="bank": _open_bank()

func _choose_size(v:String) -> void: selected_size=v; _toast("Size "+v)
func _choose_base(v:String) -> void: selected_base=v; _toast(v)
func _choose_topping(v:String) -> void: selected_topping=v; _toast(v)
func _choose_foam(v:String) -> void: selected_foam=v
func _choose_ice(v:String) -> void: selected_ice=v
func _sugar_changed(v:float) -> void: selected_sugar=int(v)

func _start_brew() -> void:
    if customer.is_empty(): _toast("Chưa có khách."); return
    recipe_started=true; recipe_step=0; brew_quality=100; _next_step()

func _next_step() -> void:
    if not recipe_started: return
    if recipe_step>=6: return
    recipe_step += 1
    var needed=[selected_size,selected_base,selected_topping,str(selected_sugar)+"% đường",selected_ice,selected_foam][recipe_step-1]
    recipe_status.text="Bước "+str(recipe_step)+": "+needed
    if recipe_step==6:
        brew_button.text="✓ ĐÃ PHA XONG"
        _toast("Ly đã pha xong. Kiểm tra đơn trước khi giao!")
    else:
        brew_button.text="➡ BƯỚC TIẾP"
    if sound_on: click_player.play()
    # Button itself can be pressed repeatedly to advance; first press starts, next advances.
    if brew_button.pressed.is_connected(_start_brew):
        brew_button.pressed.disconnect(_start_brew)
    if not brew_button.pressed.is_connected(_advance_brew):
        brew_button.pressed.connect(_advance_brew)

func _advance_brew() -> void:
    if recipe_step>=6: return
    # Small timing mechanic: every advance has a quality check.
    if patience < 25: brew_quality -= 4
    _next_step()

func _serve_customer() -> void:
    if customer.is_empty(): _toast("Không có khách đang chờ."); return
    if recipe_step < 6:
        _toast("Bạn chưa hoàn tất 6 bước pha."); return
    var correct = selected_size==customer.size and selected_base==customer.drink and selected_topping==customer.topping and selected_sugar==customer.sugar and selected_ice==customer.ice and selected_foam==customer.foam
    var price=int(prices[selected_size])
    if correct:
        price += 3000 if upgrades.marketing>=2 else 0
        money += price; revenue_today += price; served += 1; xp += 25
        rating=min(5.0,rating+0.03); _add_review(true)
        if sound_on: success_player.play()
        _toast("Đúng đơn! +"+_money(price)+" • +25 XP")
    else:
        money += int(price*0.45); revenue_today += int(price*0.45); rating=max(1.0,rating-0.18); xp += 5
        _add_review(false); _toast("Sai đơn. Khách vẫn nhận nhưng rating giảm.")
    _consume_inventory()
    _level_check(); _save_game(); _spawn_customer()
    recipe_started=false; recipe_step=0; brew_button.text="▶ BẮT ĐẦU PHA"
    if not brew_button.pressed.is_connected(_start_brew): brew_button.pressed.connect(_start_brew)
    if brew_button.pressed.is_connected(_advance_brew): brew_button.pressed.disconnect(_advance_brew)

func _consume_inventory() -> void:
    for k in [selected_base,selected_topping,selected_foam,"Đá viên","Ly "+selected_size,"Đường"]:
        if inventory.has(k): inventory[k]=max(0,int(inventory[k])-1)

func _spawn_customer() -> void:
    customer_id += 1
    var names=["Chị Diệp","Chị Duyên","Anh Tường","Bé An","Anh Minh","Mai","Khoa","Linh"]
    var drinks=["Trà sữa","Matcha","Hồng trà","Lục trà","Olong","Trà thái"]
    var tops=["Trân châu đen","Trân châu vàng","Thạch dừa","Pudding"]
    var foams=["Không foam","Foam cheese","Foam matcha","Foam muối","Foam ube"]
    var rng=RandomNumberGenerator.new(); rng.randomize()
    var drink=drinks[rng.randi_range(0,drinks.size()-1)]
    var top=tops[rng.randi_range(0,tops.size()-1)]
    var foam=foams[rng.randi_range(0,foams.size()-1)]
    var size="L" if rng.randi_range(0,100)>48 else "M"
    var sugar=[30,50,70,100][rng.randi_range(0,3)]
    var ice=["Không đá","Ít đá","Bình thường"][rng.randi_range(0,2)]
    customer={"name":names[rng.randi_range(0,names.size()-1)],"drink":drink,"topping":top,"foam":foam,"size":size,"sugar":sugar,"ice":ice}
    patience=MAX_PATIENCE; patience_bar.value=patience; customer_name_label.text="👤 "+customer.name
    selected_size=size; selected_base=drink; selected_topping=top; selected_sugar=sugar; selected_ice=ice; selected_foam=foam
    if sugar_slider: sugar_slider.value=sugar
    recipe_status.text="Khách mới • Hãy pha đúng đơn"
    _toast("Khách mới: "+customer.name)

func _customer_left_angry() -> void:
    rating=max(1.0,rating-0.12); _toast("Khách rời đi vì phải chờ quá lâu."); _spawn_customer(); _save_game()

func _clean_shop() -> void:
    if cleanliness>=100: _toast("Quán đã sạch rồi!"); return
    cleanliness=min(100,cleanliness+12); cost_today+=1000; money=max(0,money-1000); _toast("Đã dọn quán. Sạch +12 • -1.000đ"); _save_game()

func _open_inventory() -> void:
    var items="KHO\n\n"
    for k in inventory.keys(): items += k+": "+str(inventory[k])+"\n"
    _modal_text("📦 KHO NGUYÊN LIỆU",items,"Mua gói nguyên liệu: 15.000đ",func(): _buy_stock())

func _buy_stock() -> void:
    if money<15000: _toast("Không đủ tiền."); return
    money-=15000; cost_today+=15000
    for k in inventory.keys(): inventory[k]=min(int(inventory[k])+2,12+upgrades.storage*3)
    _toast("Kho đã nhập thêm nguyên liệu."); _close_modal(); _save_game()

func _open_upgrade() -> void:
    var txt="NÂNG CẤP\n\nMáy pha Lv "+str(upgrades.machine)+"\nTốc độ Lv "+str(upgrades.speed)+"\nKho Lv "+str(upgrades.storage)+"\nTrang trí Lv "+str(upgrades.decor)+"\nMarketing Lv "+str(upgrades.marketing)+"\n\nMỗi nâng cấp: "+_money(25000)
    _modal_text("🔧 NÂNG CẤP QUÁN",txt,"Mua nâng cấp",func(): _buy_upgrade())

func _buy_upgrade() -> void:
    if money<25000: _toast("Cần 25.000đ."); return
    money-=25000; cost_today+=25000
    var keys=upgrades.keys(); var k=keys[(upgrades.machine+upgrades.speed+upgrades.storage+upgrades.decor+upgrades.marketing)%keys.size()]
    upgrades[k]=min(5,int(upgrades[k])+1); _toast("Nâng cấp "+str(k)+" lên Lv "+str(upgrades[k])); _close_modal(); _save_game()

func _open_reviews() -> void:
    var txt="ĐÁNH GIÁ KHÁCH\n\n"
    if reviews.is_empty(): txt += "Chưa có đánh giá. Hãy bán ly đầu tiên!"
    else:
        for r in reviews.slice(max(0,reviews.size()-6),reviews.size()): txt += r+"\n\n"
    _modal_text("💬 REVIEW",txt,"Đóng",_close_modal)

func _open_bank() -> void:
    var txt="NGÂN HÀNG\n\nTiền mặt: "+_money(money)+"\nNợ hiện tại: "+_money(debt)+"\nĐiểm tín dụng: "+str(credit)+"\n\nGói vay: 2.000.000đ\nTrả 2.200.000đ trong 10 ngày."
    _modal_text("🏦 NGÂN HÀNG",txt,"Vay 2.000.000đ",func(): _take_loan())

func _take_loan() -> void:
    if debt>0: _toast("Bạn đang có khoản vay."); return
    if credit<550: _toast("Điểm tín dụng chưa đủ."); return
    money+=2000000; debt=2200000; credit-=30; _toast("Đã nhận khoản vay 2.000.000đ."); _close_modal(); _save_game()

var modal_panel: Panel
var modal_button: Button
func _modal_text(title:String,body:String,button_text:String,cb:Callable) -> void:
    _close_modal()
    modal_panel=Panel.new(); modal_panel.position=Vector2(360,120); modal_panel.size=Vector2(560,470); ui_layer.add_child(modal_panel)
    var t=Label.new(); t.text=title; t.position=Vector2(45,25); t.add_theme_font_override("font",font); t.add_theme_font_size_override("font_size",26); t.add_theme_color_override("font_color",brown); modal_panel.add_child(t)
    var b=Label.new(); b.text=body; b.position=Vector2(45,80); b.size=Vector2(470,320); b.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; b.add_theme_font_override("font",font); b.add_theme_font_size_override("font_size",16); modal_panel.add_child(b)
    modal_button=Button.new(); modal_button.text=button_text; modal_button.position=Vector2(195,390); modal_button.size=Vector2(170,48); modal_button.add_theme_font_override("font",font); modal_button.pressed.connect(cb); modal_panel.add_child(modal_button)
    _set_game_buttons(false)

func _close_modal() -> void:
    if modal_panel and is_instance_valid(modal_panel): modal_panel.queue_free(); modal_panel=null
    _set_game_buttons(true)

func _add_review(correct:bool) -> void:
    var cname=str(customer.name)
    var stars="★★★★★" if correct else "★★★☆☆"
    var text=""
    if cname=="Chị Diệp": text="Ly ngon, pha khá đúng đơn. Không gian dễ thương!"
    elif cname=="Chị Duyên": text="Matcha ổn, topping nhiều. Mình sẽ quay lại."
    elif cname=="Anh Tường": text="Phục vụ nhanh, quán có nhiều món để chọn."
    elif cname=="Bé An": text="Em thích trân châu đen và ly size L!"
    elif cname=="Anh Minh": text="Đơn ship đến vẫn còn đẹp và đủ topping."
    else: text="Quán dễ thương, đồ uống ổn và phục vụ thân thiện."
    reviews.append(cname+"  "+stars+"\n\""+text+"\"")

func _create_delivery() -> void:
    var price=32000+randi_range(0,15000)
    delivery_orders.append({"price":price,"timer":45.0,"drink":"Matcha"})
    _toast("🚚 Có đơn giao hàng mới: "+_money(price))

func _end_day(manual:bool) -> void:
    var tax=max(0,int((revenue_today-cost_today)*0.05))
    tax_today=tax; money=max(0,money-tax)
    if debt>0:
        var payment=220000
        if money>=payment: money-=payment; debt-=payment; _toast("Đã trả ngân hàng "+_money(payment))
        else: _toast("Không đủ tiền trả ngân hàng hôm nay.")
    if cleanliness<55: rating=max(1.0,rating-0.08)
    day+=1; day_clock=0; day_time=9.0; revenue_today=0; cost_today=0; tax_today=0
    cleanliness=max(35,cleanliness-8); credit=min(800,credit+4); _save_game(); _spawn_customer()
    _toast("🌅 Ngày "+str(day)+" bắt đầu.")

func _level_check() -> void:
    while xp>=level*100:
        xp-=level*100; level+=1; _toast("🎉 Lên Level "+str(level)+"!")

func _money(v:int) -> String:
    var s=str(v); var out=""; var count=0
    for i in range(s.length()-1,-1,-1):
        out=s[i]+out; count+=1
        if count%3==0 and i>0: out="."+out
    return out+"đ"

func _update_clock() -> void:
    if not clock_label: return
    var h=int(day_time); var m=int((day_time-h)*60.0)
    clock_label.text="Ngày "+str(day)+" • %02d:%02d"%[h,m]
    money_label.text="💰 "+_money(money)
    rating_label.text="⭐ %.1f"%rating
    level_label.text="Lv "+str(level)+" • "+str(xp)+"/"+str(level*100)+" XP"

func _toast(t:String) -> void:
    notifications.push_front(t)
    if notifications.size()>4: notifications.pop_back()

func _save_game() -> void:
    var data={"brand":brand_name,"branch":branch_name,"money":money,"rating":rating,"level":level,"xp":xp,"day":day,"cleanliness":cleanliness,"served":served,"debt":debt,"credit":credit,"inventory":inventory,"upgrades":upgrades,"reviews":reviews,"tutorial":tutorial_done}
    SaveFile.save_data(SAVE_KEY,data)

func _load_game() -> void:
    var data=SaveFile.load_data(SAVE_KEY)
    if data.is_empty(): return
    brand_name=str(data.get("brand",brand_name)); branch_name=str(data.get("branch",branch_name)); money=int(data.get("money",money)); rating=float(data.get("rating",rating)); level=int(data.get("level",level)); xp=int(data.get("xp",xp)); day=int(data.get("day",day)); cleanliness=int(data.get("cleanliness",cleanliness)); served=int(data.get("served",served)); debt=int(data.get("debt",debt)); credit=int(data.get("credit",credit)); tutorial_done=bool(data.get("tutorial",false))
    if data.has("inventory"): inventory=data.inventory
    if data.has("upgrades"): upgrades=data.upgrades
    if data.has("reviews"): reviews=data.reviews

class SaveFile:
    static func save_data(key:String,data:Dictionary) -> void:
        var f=FileAccess.open("user://"+key+".json",FileAccess.WRITE)
        if f: f.store_string(JSON.stringify(data)); f.close()
    static func load_data(key:String) -> Dictionary:
        if not FileAccess.file_exists("user://"+key+".json"): return {}
        var f=FileAccess.open("user://"+key+".json",FileAccess.READ)
        if not f: return {}
        var parsed=JSON.parse_string(f.get_as_text()); f.close()
        return parsed if parsed is Dictionary else {}
